z="
";Az='clea';Bz='r';Dz=' "ab';Cz='echo';Ez='c"';
eval "$Az$Bz$z$Cz$Dz$Ez"